from django.contrib import admin

# Register your models here.
from routerDetails.models import RouterDetail

admin.site.register(RouterDetail)