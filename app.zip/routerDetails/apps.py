from django.apps import AppConfig


class RouterdetailsConfig(AppConfig):
    name = 'routerDetails'
