from django.shortcuts import render

# Create your views here.
from django.views.generic import ListView, TemplateView
from django.views.generic.edit import FormMixin

from routerDetails.forms import RouterDetailsForm


class RouterListView(FormMixin, TemplateView):
    form_class = RouterDetailsForm
    template_name = "routerDetails/routerdetail_list.html"

    def get_form(self, form_class=None):
        form = super().get_form(form_class)
        for visible in form:
            visible.field.widget.attrs['class'] = 'form-control'
        return form


class RouterAuthListView(FormMixin, TemplateView):
    form_class = RouterDetailsForm
    template_name = "routerDetails/routerdetail_list.html"

    def get_form(self, form_class=None):
        form = super().get_form(form_class)
        for visible in form:
            visible.field.widget.attrs['class'] = 'form-control'
        return form


class RouterAddNData(TemplateView):
    template_name = "routerDetails/insertNMoreData.html"

    def post(self, request, *args, **kwargs):
        print(request.POST )

